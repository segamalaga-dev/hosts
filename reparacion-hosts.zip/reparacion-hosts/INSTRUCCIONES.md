# Reparación de la generación de hosts

El fallo de la ejecución 40942033915 se produce en build.py: URLHaus ya no existe en las fuentes de StevenBlack. El mantenedor la retiró el 27 de octubre de 2026 porque requiere autenticación. Las advertencias sobre Node.js y Ubuntu de la captura no causan este fallo.

## Cambios preparados

- Retirada explícita de URLHaus, conservando StevenBlack, AdAway, add.2o7Net, someonewhocares.org y yoyo.org.
- Exclusión de todas las demás carpetas antes de ejecutar el generador oficial, incluidas hostsVN y KADhosts.
- Mensaje de error que identifica cualquier fuente seleccionada que falte. No se ignoran ausencias silenciosamente.
- Uso del mismo intérprete de Python para ejecutar el generador original.
- Comprobación de generación en los PR; el paso de publicación de hosts se omite en los PR.
- README actualizado con la evaluación de alternativas. No se añade otra lista.

## Validación realizada

Con la copia original de StevenBlack en el commit 11550239d5714d60b62be8796446ecba84a1bfb2, se ejecutó el generador oficial sin descargas adicionales, usando Requests 2.34.2 incluido en el entorno disponible. Solo se sustituyó la descarga inicial por una copia local de ese mismo commit para la prueba.

Resultado: 27.147 dominios, idénticos y sin duplicados en Android y Windows. Verificados los formatos, un dominio por línea en Android, hasta nueve en Windows y finales de línea CRLF en Windows. Se comprobó que únicamente las cinco carpetas autorizadas llegan al generador y que la ausencia de URLHaus o de otra fuente requerida provoca un error sin reemplazar los resultados anteriores.

No se ha podido publicar una rama ni crear el PR: el conector de GitHub devuelve HTTP 403, Resource not accessible by integration. No hay ejecución de GitHub Actions de la reparación todavía. La rama main permanece intacta.

## Aplicar y crear el PR

En una copia actualizada de segamalaga-dev/hosts, crear una rama y aplicar reparacion.patch:

```bash
git switch -c fix/urlhaus-retired-source
git apply --check /ruta/a/reparacion.patch
git apply /ruta/a/reparacion.patch
git add build.py README.md .github/workflows/update-hosts.yml
git commit -m "Fix selected hosts build after upstream URLHaus removal"
git push -u origin fix/urlhaus-retired-source
```

También se pueden reemplazar manualmente los tres archivos con las copias incluidas en este paquete, respetando sus rutas. INSTRUCCIONES.md y reparacion.patch no necesitan subirse al repositorio.

Crear un PR hacia main. La nueva comprobación ejecutará la generación completa sin publicar los resultados. Al fusionar, la ejecución de main regenerará y publicará hosts y hosts-windows. No basta con reejecutar el intento antiguo: seguirá usando el código anterior.

Título sugerido del PR: Fix selected hosts build after upstream URLHaus removal

Descripción: La generación falla porque StevenBlack retiró URLHaus el 27 de octubre de 2026. Se elimina esta fuente inaccesible, conservando las otras cinco y las exclusiones deliberadas, y se documentan las alternativas revisadas. Se añade generación de prueba para PR sin publicar hosts. Validación local con el generador oficial: 27.147 dominios idénticos en Android y Windows, formatos correctos y protección de resultados cuando falta una fuente seleccionada.
