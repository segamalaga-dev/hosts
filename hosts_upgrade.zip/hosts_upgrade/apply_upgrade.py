#!/usr/bin/env python3
"""Patch segamalaga-dev/hosts locally without changing generated hosts before validation."""
from pathlib import Path
p=Path.cwd()
for required in ['build.py','README.md','.github/workflows/update-hosts.yml']:
    if not (p/required).is_file():
        raise SystemExit(f'Execute in repository root; missing {required}')
b=p/'build.py'
s=b.read_text()
if 'FROGEYE_URL' in s: raise SystemExit('Already patched; no changes made')
assert 'import tempfile\n' in s and 'DOMAIN = re.compile' in s
s=s.replace('import tempfile\n','import tempfile\nimport requests\n')
helper='''FROGEYE_URL = "https://hostfiles.frogeye.fr/firstparty-only-trackers-hosts.txt"
# The actual URLhaus hostfile export URL must be stored as an Actions secret.
# Never embed a URLhaus key in source control or print a URL containing it.
MAX_EXTERNAL_DOMAINS = 50000


def load_external_hosts(url, source):
    if not url.startswith('https://'):
        raise RuntimeError(source + ': expected HTTPS feed URL')
    try:
        response = requests.get(url, timeout=(15, 90), headers={'User-Agent': 'segamalaga-hosts/1.0'})
        response.raise_for_status()
        if len(response.content) > 8_000_000:
            raise ValueError('oversized response')
        body = response.content.decode('utf-8-sig')
    except Exception:
        # Never include the exception text: authenticated URLs can contain secrets.
        raise RuntimeError(source + ': fetch failed; URL and credentials suppressed') from None
    domains = set()
    malformed = 0
    for raw in body.splitlines():
        clean = raw.partition('#')[0].strip()
        if not clean:
            continue
        fields = clean.split()
        if fields[0] in ('0.0.0.0', '127.0.0.1') and len(fields) > 1:
            candidates = fields[1:]
        elif len(fields) == 1:
            candidates = fields
        else:
            malformed += 1
            continue
        for item in candidates:
            item = item.lower().rstrip('.')
            if item != 'localhost' and DOMAIN.fullmatch(item):
                try:
                    ipaddress.ip_address(item)
                except ValueError:
                    domains.add(item)
            else:
                malformed += 1
    if not 10 <= len(domains) <= MAX_EXTERNAL_DOMAINS:
        raise RuntimeError(f'{source}: unexpected domain count ({len(domains)})')
    if malformed > max(50, len(domains) // 20):
        raise RuntimeError(f'{source}: unexpectedly many invalid entries')
    return domains


'''
s=s.replace('DOMAIN = re.compile',helper+'DOMAIN = re.compile',1)
needle='        if len(domains) < 10000:'
assert needle in s
s=s.replace(needle,'''        # Preserve upstream fusion. Deduplicate external feeds against the result.
        base_count = len(domains)
        frogeye = load_external_hosts(FROGEYE_URL, 'Frogeye')
        domains.update(frogeye)
        print(f'Frogeye: {len(domains)-base_count} net new domains')
        urlhaus_url = os.environ.get('URLHAUS_HOSTFILE_URL', '').strip()
        if urlhaus_url:
            prior = len(domains)
            domains.update(load_external_hosts(urlhaus_url, 'URLhaus'))
            print(f'URLhaus: {len(domains)-prior} net new domains')
        else:
            print('URLhaus: NOT ACTIVE (Actions secret missing)')

'''+needle,1)
b.write_text(s)
w=p/'.github/workflows/update-hosts.yml';x=w.read_text()
assert '      - run: python3 build.py' in x
x=x.replace('      - run: python3 build.py', '''      - name: Generate filtered hosts
        env:
          URLHAUS_HOSTFILE_URL: ${{ secrets.URLHAUS_HOSTFILE_URL }}
        run: python3 build.py''',1)
x=x.replace('cron: "17 5 * * 1"','cron: "17 5 * * *"')
w.write_text(x)
r=p/'README.md';t=r.read_text();t+='''\n\n## Optional external privacy and malware feeds\n\nThe build adds [Frogeye first-party-only hosts](https://hostfiles.frogeye.fr/) to the selected StevenBlack sources; it is a privacy/tracker list, **not** an anti-malware feed.\n\nSince upstream StevenBlack no longer carries URLhaus, this build optionally consumes the authenticated URLhaus **hostfile** export as `URLHAUS_HOSTFILE_URL`. Store the complete authenticated HTTPS hostfile URL in **Settings → Secrets and variables → Actions → New repository secret**. Do not store or print the secret in git. The URL's exact path must come from the [URLhaus API documentation after login](https://urlhaus.abuse.ch/api/). Without the secret, URLhaus is skipped, and the action log explicitly says so. Rotate any previously disclosed API key.\n\nThe external feeds are validated and deduplicated with the existing sources, and the workflow is scheduled daily. Check each feed's redistribution terms before publishing combined hosts files, and inspect generated diffs for service breakage.\n''';r.write_text(t)
print('Updated build.py, workflow and README. Run python3 -m pip install -r requirements.txt && python3 build.py; inspect git diff before commit.')
