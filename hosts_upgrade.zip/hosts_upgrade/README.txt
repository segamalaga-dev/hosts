1. Clone or open your segamalaga-dev/hosts repository and create a new branch.
2. Copy apply_upgrade.py to the repository root; run python3 apply_upgrade.py.
3. From the repo: python3 -m pip install -r requirements.txt; python3 build.py.
4. Inspect git diff --stat, git diff and domain counts; run any tests.
5. Make a Pull Request for the three source changes and generated output (if desired).
6. In GitHub Settings > Secrets and variables > Actions, set URLHAUS_HOSTFILE_URL to the FULL authenticated URL for the URLhaus hostfile export (from the URLhaus documentation after login). Rotate the key previously shared in chat.
7. Re-run Actions and verify both Frogeye and URLhaus net additions are logged. Never put credentials in README/PR/logs.
8. Review legal redistribution terms, especially for a public repository.
Notes: without the Actions secret, URLhaus is not active. This patch does not yet quantify URLhaus domain count. If the live hostfile format changes, the validation intentionally fails rather than publishing unverified output.
